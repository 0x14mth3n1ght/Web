<?php
include_once '../src/utils/autoloader.php';
include_once '../src/View/template.php';
loadView('signup', []);

?>